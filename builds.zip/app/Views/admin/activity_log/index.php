<?= $this->extend('layouts/user_layout') ?>

<?= $this->section('content') ?>
<div class="container-fluid px-2 px-md-4 py-3">
    <!-- Header -->
    <div class="d-flex flex-column flex-sm-row align-items-start align-items-sm-center justify-content-between gap-3 mb-4">
        <div>
            <h1 class="h3 mb-1 text-gray-800 fw-bold"><i class="fas fa-history me-2 text-primary"></i>Log Aktivitas Sistem</h1>
            <p class="text-muted small mb-0">Catatan riwayat transaksi, perubahan data, dan aktivitas yang terjadi di dalam sistem.</p>
        </div>
    </div>

    <!-- Filter Card -->
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-header bg-white py-3">
            <form action="<?= base_url('admin/activity-log') ?>" method="get" class="row g-2 align-items-end">
                <div class="col-md-3 col-12">
                    <label class="form-label text-muted small fw-semibold mb-1">Pengguna</label>
                    <select name="user_id" class="form-select">
                        <option value="">Semua Pengguna</option>
                        <?php foreach ($users as $u): ?>
                            <option value="<?= $u['id'] ?>" <?= $filters['user_id'] == $u['id'] ? 'selected' : '' ?>><?= esc($u['nama']) ?> (<?= esc($u['username']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4 col-12">
                    <label class="form-label text-muted small fw-semibold mb-1">Kata Kunci Aktivitas</label>
                    <input type="text" name="search" class="form-control" value="<?= esc($filters['search']) ?>" placeholder="Cari deskripsi aktivitas...">
                </div>
                <div class="col-md-3 col-12">
                    <label class="form-label text-muted small fw-semibold mb-1">Rentang Tanggal</label>
                    <div class="input-group">
                        <input type="date" name="start_date" class="form-control" value="<?= esc($filters['start_date']) ?>">
                        <span class="input-group-text">-</span>
                        <input type="date" name="end_date" class="form-control" value="<?= esc($filters['end_date']) ?>">
                    </div>
                </div>
                <div class="col-md-2 col-12 d-flex gap-2">
                    <button type="submit" class="btn btn-primary w-100"><i class="fas fa-filter me-1"></i> Filter</button>
                    <a href="<?= base_url('admin/activity-log') ?>" class="btn btn-light border"><i class="fas fa-sync"></i></a>
                </div>
            </form>
        </div>
        <div class="card-body p-3 p-md-4 pt-0">
            <!-- Desktop Table View -->
            <div class="d-none d-md-block table-responsive border shadow-sm rounded-4">
                <table class="table table-hover align-middle bg-white mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">No</th>
                            <th>Waktu Log</th>
                            <th>Pengguna</th>
                            <th>Aktivitas</th>
                            <th class="text-end pe-4">Detail Data</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($logs)): ?>
                            <tr>
                                <td colspan="5" class="text-center py-5 text-muted">
                                    <i class="fas fa-history fa-3x mb-3 d-block opacity-50"></i>
                                    Belum ada catatan aktivitas sistem.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $no = 1; foreach ($logs as $log): ?>
                                <tr>
                                    <td class="ps-4 text-muted small"><?= $no++ ?></td>
                                    <td>
                                        <div class="fw-semibold text-dark"><?= date('d M Y, H:i', strtotime($log['waktu'])) ?></div>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-dark"><?= esc($log['user_name'] ?? 'Sistem') ?></div>
                                        <small class="text-muted">Role: <?= esc($log['role'] ?? '-') ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark p-2 text-wrap text-start border fw-normal fs-6">
                                            <?= esc($log['aktivitas']) ?>
                                        </span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <?php if ($log['data_sebelum'] || $log['data_sesudah']): ?>
                                            <button type="button" class="btn btn-sm btn-outline-info rounded-pill px-3" onclick='showLogDetail(<?= json_encode($log['data_sebelum']) ?>, <?= json_encode($log['data_sesudah']) ?>)'>
                                                <i class="fas fa-eye me-1"></i> Data
                                            </button>
                                        <?php else: ?>
                                            <span class="text-muted small">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Mobile Card View -->
            <div class="d-block d-md-none">
                <?php if (empty($logs)): ?>
                    <div class="text-center py-5 text-muted border rounded-4 bg-light shadow-sm">
                        <i class="fas fa-history fa-3x mb-3 d-block opacity-50"></i>
                        Belum ada catatan aktivitas sistem.
                    </div>
                <?php else: ?>
                    <div class="d-flex flex-column gap-3">
                        <?php foreach ($logs as $log): ?>
                            <div class="card border-0 rounded-4 shadow-sm bg-white">
                                <div class="card-body p-3">
                                    <div class="d-flex justify-content-between align-items-start border-bottom pb-2 mb-2" style="border-color: #f1f5f9 !important;">
                                        <div>
                                            <div class="fw-bold text-dark fs-6"><?= esc($log['user_name'] ?? 'Sistem') ?></div>
                                            <small class="text-muted"><i class="fas fa-user-tag text-secondary"></i> <?= esc($log['role'] ?? '-') ?></small>
                                        </div>
                                        <div class="text-end">
                                            <div class="fw-semibold text-dark text-nowrap small"><i class="fas fa-clock fs-6"></i> <?= date('d M Y, H:i', strtotime($log['waktu'])) ?></div>
                                        </div>
                                    </div>
                                    <div class="d-flex flex-column gap-2 mb-2">
                                        <span class="text-secondary fw-normal fs-6">
                                            <?= esc($log['aktivitas']) ?>
                                        </span>
                                    </div>
                                    <div class="d-flex justify-content-end pt-2 border-top" style="border-color: #f1f5f9 !important;">
                                        <?php if ($log['data_sebelum'] || $log['data_sesudah']): ?>
                                            <button type="button" class="btn btn-sm btn-outline-info rounded-pill px-4 shadow-sm" onclick='showLogDetail(<?= json_encode($log['data_sebelum']) ?>, <?= json_encode($log['data_sesudah']) ?>)'>
                                                <i class="fas fa-eye me-1"></i> Data
                                            </button>
                                        <?php else: ?>
                                            <span class="badge bg-light text-muted fw-normal"><i class="fas fa-minus"></i></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal Detail Log -->
<div class="modal fade" id="logDetailModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <div class="modal-header bg-info text-white rounded-top-4">
                <h5 class="modal-title fw-bold"><i class="fas fa-info-circle me-2"></i>Detail Perubahan Data</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row g-3">
                    <div class="col-md-6 col-12">
                        <label class="fw-bold text-danger mb-2">Data Sebelum:</label>
                        <pre id="dataSebelumJson" class="bg-light p-3 rounded-3 border text-wrap small" style="max-height: 250px; overflow-y: auto;"></pre>
                    </div>
                    <div class="col-md-6 col-12">
                        <label class="fw-bold text-success mb-2">Data Sesudah:</label>
                        <pre id="dataSesudahJson" class="bg-light p-3 rounded-3 border text-wrap small" style="max-height: 250px; overflow-y: auto;"></pre>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light rounded-bottom-4">
                <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script>
    function showLogDetail(sebelum, sesudah) {
        try {
            document.getElementById('dataSebelumJson').textContent = sebelum ? JSON.stringify(JSON.parse(sebelum), null, 2) : 'Kosong / Tidak Ada';
        } catch(e) {
            document.getElementById('dataSebelumJson').textContent = sebelum || 'Kosong / Tidak Ada';
        }
        try {
            document.getElementById('dataSesudahJson').textContent = sesudah ? JSON.stringify(JSON.parse(sesudah), null, 2) : 'Kosong / Tidak Ada';
        } catch(e) {
            document.getElementById('dataSesudahJson').textContent = sesudah || 'Kosong / Tidak Ada';
        }
        var modal = new bootstrap.Modal(document.getElementById('logDetailModal'));
        modal.show();
    }
</script>
<?= $this->endSection() ?>
